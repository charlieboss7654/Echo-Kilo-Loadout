Config = {}

-- ==============================
-- General Settings
-- ==============================

-- Keybind to open the loadout menu (also has /loadout)
Config.OpenKey = 'F5'

-- Remove all weapons before giving a loadout
Config.ClearBeforeGive = true

-- Fallback armour if a loadout doesn�t specify one
Config.DefaultArmour = 0

-- Simple chat notify for equip / denied messages
Config.ChatNotify = true

-- Discord webhook for armoury logging (leave blank to disable)
Config.ArmouryWebhook = ''

-- ==============================
-- Armoury / ox_target Integration
-- ==============================

Config.Armoury = {
    Enabled     = true,  -- Master switch for armoury system
    UseOxTarget = true,  -- Enable ox_target interactions

    Locations = {

        -- ======================================================
        -- 1) MISSION ROW � MP PED ARMOURER
        -- ======================================================
        {
            id      = 'mr_mp_armoury',
            label   = 'Mission Row Armoury (MP Ped)',
            coords  = vector3(454.0, -980.0, 30.69),
            heading = 90.0,

            blip = {
                sprite = 110,
                colour = 29,
                scale  = 0.8
            },

            loadouts = { 'patrol', 'swat' },

            ped = {
                type  = 'mp',                   -- Use MP ped system
                model = 'mp_m_freemode_01',     -- Base model

                -- ===========================================================
                --   ?? FULL MP PED CUSTOMISATION SECTION ??
                -- ===========================================================
                appearance = {

                    -- Ped model (mp male/female)
                    model = 'mp_m_freemode_01',

                    -- ===============================
                    -- FACE: HEAD BLEND (Parents)
                    -- ===============================
                    headBlend = {
                        shapeFirst = 21, shapeSecond = 0, shapeThird = 0,
                        skinFirst  = 21, skinSecond  = 0, skinThird  = 0,
                        shapeMix   = 0.5,
                        skinMix    = 0.5,
                        thirdMix   = 0.0
                    },

                    -- ===============================
                    -- FACE FEATURES (0�19 sliders)
                    -- ===============================
                    -- All values: -1.0 to +1.0
                    faceFeatures = {
                        [0] = 0.0,  -- Nose Width
                        [1] = 0.0,  -- Nose Peak Height
                        [2] = 0.0,  -- Nose Peak Length
                        [3] = 0.0,  -- Nose Bone Height
                        [4] = 0.0,  -- Nose Peak Lowering
                        [5] = 0.0,  -- Nose Bone Twist
                        [6] = 0.0,  -- Eyebrow Height
                        [7] = 0.0,  -- Eyebrow Width
                        [8] = 0.0,  -- Cheekbone Height
                        [9] = 0.0,  -- Cheekbone Width
                        [10] = 0.0, -- Cheek Width
                        [11] = 0.0, -- Eye Opening
                        [12] = 0.0, -- Lips Thickness
                        [13] = 0.0, -- Jaw Width
                        [14] = 0.0, -- Jaw Height
                        [15] = 0.0, -- Chin Length
                        [16] = 0.0, -- Chin Position
                        [17] = 0.0, -- Chin Shape
                        [18] = 0.0, -- Chin Width
                        [19] = 0.0, -- Neck Width
                    },

                    -- ===============================
                    -- HAIR + COLOUR
                    -- ===============================
                    hair = {
                        style     = 4,  -- Hair drawable ID
                        color     = 2,  -- Primary colour
                        highlight = 0   -- Highlight colour
                    },

                    -- ===============================
                    -- EYE COLOUR (0�31)
                    -- ===============================
                    eyeColor = 3,

                    -- ===============================
                    -- FACIAL OVERLAYS (FULL CONTROL)
                    -- ===============================
                    -- overlayID = { index, opacity }
                    -- Example overlays:
                    -- 0 = Blemishes, 1 = Facial Hair, 2 = Eyebrows, 3 = Ageing, 4 = Makeup� etc.
                    overlays = {
                        [0]  = { index = 0, opacity = 1.0 }, -- Blemishes
                        [1]  = { index = 0, opacity = 1.0 }, -- Facial Hair
                        [2]  = { index = 0, opacity = 1.0 }, -- Eyebrows
                        [3]  = { index = 0, opacity = 1.0 }, -- Ageing
                        [4]  = { index = 0, opacity = 1.0 }, -- Makeup
                        [5]  = { index = 0, opacity = 1.0 }, -- Blush
                        [6]  = { index = 0, opacity = 1.0 }, -- Complexion
                        [7]  = { index = 0, opacity = 1.0 }, -- Sun Damage
                        [8]  = { index = 0, opacity = 1.0 }, -- Lipstick
                        [9]  = { index = 0, opacity = 1.0 }, -- Moles / Freckles
                        [10] = { index = 0, opacity = 1.0 }, -- Chest Hair
                        [11] = { index = 0, opacity = 1.0 }, -- Body Blemishes
                    },

                    -- ===============================
                    -- FULL CLOTHING (COMPONENTS 0�11)
                    -- ===============================
                    -- Component list:
                    -- 0 = Face, 1 = Mask, 2 = Hair, 3 = Torso, 4 = Legs,
                    -- 5 = Bags, 6 = Shoes, 7 = Accessories,
                    -- 8 = Undershirts, 9 = Armour, 10 = Decals, 11 = Tops
                    components = {
                        [3]  = { drawable = 0,   texture = 0 },   -- Torso
                        [4]  = { drawable = 35,  texture = 0 },   -- Legs
                        [6]  = { drawable = 7,   texture = 0 },   -- Shoes
                        [8]  = { drawable = 16,  texture = 0 },   -- Undershirt
                        [11] = { drawable = 423, texture = 0 },   -- Jacket / Top
                    },

                    -- ===============================
                    -- PROPS
                    -- ===============================
                    -- 0 = Hat, 1 = Glasses, 2 = Earring,
                    -- 6 = Watch, 7 = Bracelet
                    props = {
                        [0] = { drawable = -1, texture = 0 }, -- Hat
                        [1] = { drawable = -1, texture = 0 }, -- Glasses
                        [2] = { drawable = -1, texture = 0 }, -- Earring
                        [6] = { drawable = -1, texture = 0 }, -- Watch
                        [7] = { drawable = -1, texture = 0 }, -- Bracelet
                    }
                }
            }
        },

        -- ======================================================
        -- 2) SANDY SHORES � BASE GAME COP ARMOURER
        -- ======================================================
        {
            id      = 'sandy_base_armoury',
            label   = 'Sandy Shores Armoury (Base Ped)',
            coords  = vector3(1853.0, 3689.0, 34.27),
            heading = 210.0,

            blip = {
                sprite = 110,
                colour = 38,
                scale  = 0.8
            },

            loadouts = { 'patrol', 'detective' },

            ped = {
                type  = 'base',
                model = 's_m_y_cop_01'
            }
        }
    }
}

-- ==============================
-- Component Labels
-- (unchanged from your file)
-- ==============================

Config.ComponentLabels = {
    COMPONENT_AT_AR_FLSH        = 'Flashlight',
    COMPONENT_AT_PI_FLSH        = 'Pistol Flashlight',
    COMPONENT_AT_PI_SUPP        = 'Pistol Suppressor',
    COMPONENT_AT_AR_SUPP        = 'Rifle Suppressor',
    COMPONENT_AT_SCOPE_MACRO    = 'Holographic Sight',
    COMPONENT_AT_SCOPE_MACRO_02 = 'Micro-dot Sight',
    COMPONENT_AT_SCOPE_MEDIUM   = 'ACOG Scope',
    COMPONENT_AT_AR_AFGRIP      = 'Foregrip',
}

-- ==============================
-- Attachment Catalog
-- (unchanged)
-- ==============================

Config.AttachmentCatalog = {
    WEAPON_PISTOL = {
        'COMPONENT_AT_PI_FLSH',
        'COMPONENT_AT_PI_SUPP'
    },
    WEAPON_COMBATPISTOL = {
        'COMPONENT_AT_PI_FLSH',
        'COMPONENT_AT_PI_SUPP'
    },
    WEAPON_CARBINERIFLE = {
        'COMPONENT_AT_AR_FLSH',
        'COMPONENT_AT_SCOPE_MACRO',
        'COMPONENT_AT_SCOPE_MACRO_02',
        'COMPONENT_AT_SCOPE_MEDIUM',
        'COMPONENT_AT_AR_AFGRIP',
        'COMPONENT_AT_AR_SUPP',
        'COMPONENT_CARBINERIFLE_CLIP_01',
        'COMPONENT_CARBINERIFLE_CLIP_02',
    },
    WEAPON_PUMPSHOTGUN = {
        'COMPONENT_AT_AR_FLSH',
        'COMPONENT_PUMPSHOTGUN_CLIP_01',
    },
}
-- ==============================
-- Loadout Definitions
-- ==============================

Config.Loadouts = {
    patrol = {
        title       = 'Patrol Loadout',
        description = 'Standard issue sidearm and rifle for frontline response.',
        armour      = 50,

        -- Require at least one of these Discord roles to use:
        discordRoles = {
            'EKS | Response Officer',
            'EKS | Senior Response'
        },

        weapons = {
            {
                name  = 'WEAPON_PISTOL',
                label = 'Glock 17 (Pistol)',
                ammo  = 90,
                components = {
                    'COMPONENT_AT_PI_FLSH',
                    'COMPONENT_AT_PI_SUPP'
                }
            },
            {
                name  = 'WEAPON_CARBINERIFLE',
                label = 'AR-15 (Carbine)',
                ammo  = 180,
                components = {
                    'COMPONENT_AT_AR_FLSH',
                    'COMPONENT_AT_SCOPE_MEDIUM',
                    'COMPONENT_AT_AR_AFGRIP',
                    'COMPONENT_AT_AR_SUPP'
                }
            },
            { name = 'WEAPON_STUNGUN',    label = 'TASER',     ammo = 5 },
            { name = 'WEAPON_NIGHTSTICK', label = 'ASP Baton', ammo = 1 },
        }
    },

    swat = {
        title       = 'Armed Response',
        description = 'CQB-focused package for high-risk entries and support.',
        armour      = 100,

        discordRoles = {
            'EKS | Firearms Officer',
            'EKS | Senior Firearms'
        },

        weapons = {
            {
                name  = 'WEAPON_SMG',
                label = 'MP5 (SMG)',
                ammo  = 200,
                components = {
                    'COMPONENT_AT_AR_FLSH',
                    'COMPONENT_AT_SCOPE_MACRO_02'
                }
            },
            {
                name  = 'WEAPON_PUMPSHOTGUN',
                label = 'Remington 870',
                ammo  = 40,
                components = {
                    'COMPONENT_AT_AR_FLSH'
                }
            },
            {
                name  = 'WEAPON_COMBATPISTOL',
                label = 'Glock 19 (Combat Pistol)',
                ammo  = 120,
                components = {
                    'COMPONENT_AT_PI_FLSH',
                    'COMPONENT_AT_PI_SUPP'
                }
            },
        }
    },

    detective = {
        title       = 'Detective Loadout',
        description = 'Plainclothes setup with low-profile options.',
        armour      = 25,

        discordRoles = {
            'EKS | Founder',
            'EKS | Senior Detective'
        },

        weapons = {
            {
                name  = 'WEAPON_COMBATPISTOL',
                label = 'Glock 19',
                ammo  = 90,
                components = { 'COMPONENT_AT_PI_FLSH' },
            },
            {
                name  = 'WEAPON_FLASHLIGHT',
                label = 'Maglite',
                ammo  = 1
            },
        }
    }
}

-- ==============================
-- Category Tree (Menu Layout)
-- ==============================

Config.Tree = {
    {
        id    = 'nh_constabulary',
        label = 'New Hartshire Constabulary',
        children = {
            {
                id    = 'nh_firearms',
                label = 'Firearms',
                children = {
                    {
                        id       = 'nh_firearms_loadouts',
                        label    = 'Firearms Loadouts',
                        loadouts = { 'swat', 'patrol' }
                    }
                }
            },
            {
                id       = 'nh_detectives',
                label    = 'CID',
                loadouts = { 'detective' }
            }
        }
    }
}
