Config = {}

-- Keybind (also has /loadout)
Config.OpenKey = 'F5'

-- Remove all weapons before giving a loadout
Config.ClearBeforeGive = true

-- Fallback armour if a loadout doesn't specify one
Config.DefaultArmour = 0

-- Simple chat notify
Config.ChatNotify = true

-- ==============================
-- Component -> Friendly Label
-- (Add anything you use here)
-- ==============================
Config.ComponentLabels = {
  -- Pistol family
  COMPONENT_AT_PI_FLSH       = 'Pistol Flashlight',
  COMPONENT_AT_PI_SUPP       = 'Pistol Suppressor',
  COMPONENT_AT_PI_SUPP_02    = 'Pistol Suppressor (Alt)',
  COMPONENT_PISTOL_CLIP_01   = 'Pistol Mag',
  COMPONENT_PISTOL_CLIP_02   = 'Pistol Extended Mag',

  -- Combat Pistol
  COMPONENT_COMBATPISTOL_CLIP_01 = 'Combat Pistol Mag',
  COMPONENT_COMBATPISTOL_CLIP_02 = 'Combat Pistol Extended Mag',

  -- SMG
  COMPONENT_AT_SCOPE_MACRO       = 'Holo/Micro Scope',
  COMPONENT_AT_SCOPE_MACRO_02    = 'Micro Scope Mk2',
  COMPONENT_AT_AR_FLSH           = 'Weapon Flashlight',
  COMPONENT_SMG_CLIP_01          = 'SMG Mag',
  COMPONENT_SMG_CLIP_02          = 'SMG Extended Mag',
  COMPONENT_AT_AR_SUPP_02        = 'SMG Suppressor',

  -- Carbine Rifle
  COMPONENT_AT_AR_SUPP           = 'AR Suppressor',
  COMPONENT_AT_AR_AFGRIP         = 'Foregrip',
  COMPONENT_AT_SCOPE_MEDIUM      = 'Scope (Medium)',
  COMPONENT_CARBINERIFLE_CLIP_01 = 'Rifle Mag',
  COMPONENT_CARBINERIFLE_CLIP_02 = 'Rifle Extended Mag',

  -- Shotgun
  COMPONENT_PUMPSHOTGUN_CLIP_01  = 'Shotgun Shells',

  -- Utility
  COMPONENT_AT_SCOPE_SMALL_02    = 'Small Scope',
}

-- =========================================================
-- Attachment catalog: what players can optionally add later
-- per weapon (hash names). Extend as needed.
-- =========================================================
Config.AttachmentCatalog = {
  WEAPON_PISTOL = {
    'COMPONENT_AT_PI_FLSH',
    'COMPONENT_AT_PI_SUPP',
    'COMPONENT_PISTOL_CLIP_01',
    'COMPONENT_PISTOL_CLIP_02',
  },
  WEAPON_COMBATPISTOL = {
    'COMPONENT_AT_PI_FLSH',
    'COMPONENT_AT_PI_SUPP',
    'COMPONENT_COMBATPISTOL_CLIP_01',
    'COMPONENT_COMBATPISTOL_CLIP_02',
  },
  WEAPON_SMG = {
    'COMPONENT_AT_AR_FLSH',
    'COMPONENT_AT_SCOPE_MACRO',
    'COMPONENT_AT_SCOPE_MACRO_02',
    'COMPONENT_SMG_CLIP_01',
    'COMPONENT_SMG_CLIP_02',
    'COMPONENT_AT_AR_SUPP_02',
  },
  WEAPON_CARBINERIFLE = {
    'COMPONENT_AT_AR_FLSH',
    'COMPONENT_AT_AR_AFGRIP',
    'COMPONENT_AT_AR_SUPP',
    'COMPONENT_AT_SCOPE_MEDIUM',
    'COMPONENT_CARBINERIFLE_CLIP_01',
    'COMPONENT_CARBINERIFLE_CLIP_02',
  },
  WEAPON_PUMPSHOTGUN = {
    'COMPONENT_AT_AR_FLSH',
    'COMPONENT_PUMPSHOTGUN_CLIP_01',
  },
}

-- ==============================
--       LOADOUT DEFINITIONS
-- Per-weapon display names via `label`
-- (logic still uses `name` hash)
-- ==============================
Config.Loadouts = {
  patrol = {
    title = 'Patrol Loadout',
    description = 'Standard issue sidearm and rifle for frontline response.',
    armour = 50,
    weapons = {
      { name = 'WEAPON_PISTOL',       label = 'Glock 17 (Pistol)', ammo = 84,  components = { 'COMPONENT_AT_PI_FLSH', 'COMPONENT_AT_PI_SUPP' } },
      { name = 'WEAPON_CARBINERIFLE', label = 'AR-15 (Carbine)',   ammo = 180, components = { 'COMPONENT_AT_AR_FLSH', 'COMPONENT_AT_AR_AFGRIP', 'COMPONENT_AT_AR_SUPP', 'COMPONENT_AT_SCOPE_MEDIUM' } },
      { name = 'WEAPON_STUNGUN',      label = 'TASER',             ammo = 5 },
      { name = 'WEAPON_NIGHTSTICK',   label = 'ASP Baton',         ammo = 1 },
    }
  },

  swat = {
    title = 'Armed Response',
    description = 'CQB-focused package for high-risk entries and support.',
    armour = 100,
    weapons = {
      { name = 'WEAPON_SMG',          label = 'MP5 (SMG)',         ammo = 240, components = { 'COMPONENT_AT_AR_FLSH', 'COMPONENT_AT_SCOPE_MACRO_02' } },
      { name = 'WEAPON_PUMPSHOTGUN',  label = 'Remington 870',     ammo = 40,  components = { 'COMPONENT_AT_AR_FLSH' } },
      { name = 'WEAPON_COMBATPISTOL', label = 'Glock 19 (Combat)', ammo = 120, components = { 'COMPONENT_AT_PI_FLSH', 'COMPONENT_AT_PI_SUPP' } },
    }
  },

  detective = {
    title = 'Detective Loadout',
    description = 'Plainclothes setup with low-profile options.',
    armour = 25,
    weapons = {
      { name = 'WEAPON_COMBATPISTOL', label = 'Glock 19',          ammo = 90, components = { 'COMPONENT_AT_PI_FLSH' } },
      { name = 'WEAPON_FLASHLIGHT',   label = 'Maglite',            ammo = 1 },
    }
  }
}

-- ==============================
--         CATEGORY TREE
-- ==============================
Config.Tree = {
  {
    id = 'nh_constabulary',
    label = 'New Hartshire Constabulary',
    children = {
      {
        id = 'nh_firearms',
        label = 'Firearms',
        children = {
          { id = 'nh_firearms_loadouts', label = 'Firearms Loadouts', loadouts = { 'swat', 'patrol' } }
        }
      },
      { id = 'nh_detectives', label = 'CID', loadouts = { 'detective' } }
    }
  }
}
