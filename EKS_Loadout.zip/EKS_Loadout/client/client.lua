local RES = GetCurrentResourceName()
local uiOpen = false

local function _hash(s)
    if type(joaat) == 'function' then
        return joaat(s)
    end
    return GetHashKey(s)
end

local function knownComponentsForWeapon(weaponName)
    local known = {}

    if Config.AttachmentCatalog and Config.AttachmentCatalog[weaponName] then
        for _, c in ipairs(Config.AttachmentCatalog[weaponName]) do
            known[c] = true
        end
    end

    if Config.Loadouts then
        for _, lo in pairs(Config.Loadouts) do
            if lo.weapons then
                for _, w in ipairs(lo.weapons) do
                    if w.name == weaponName and w.components then
                        for _, c in ipairs(w.components) do
                            known[c] = true
                        end
                    end
                end
            end
        end
    end

    local out = {}
    for k in pairs(known) do
        out[#out + 1] = k
    end
    return out
end

local function applyLoadoutLocal(ped, lo, extras)
    extras = extras or {}
    local clearFirst = (Config.ClearBeforeGive ~= false)

    if clearFirst then
        RemoveAllPedWeapons(ped, true)
    end

    local armour = lo.armour
    if type(armour) ~= 'number' then
        armour = Config.DefaultArmour or 0
    end
    SetPedArmour(ped, armour)

    if lo.weapons then
        for _, w in ipairs(lo.weapons) do
            local wName = w.name
            local ammo  = w.ammo or 0
            local wHash = _hash(wName)
            if wHash ~= 0 then
                GiveWeaponToPed(ped, wHash, ammo, false, false)

                local baseComponents = w.components or {}

                local extraComponents = {}
                if extras[wName] then
                    extraComponents = extras[wName]
                end

                local desired = {}
                for _, c in ipairs(baseComponents) do desired[c] = true end
                for _, c in ipairs(extraComponents) do desired[c] = true end

                for _, c in ipairs(knownComponentsForWeapon(wName)) do
                    local cHash = _hash(c)
                    if cHash ~= 0 and HasPedGotWeaponComponent(ped, wHash, cHash) and not desired[c] then
                        RemoveWeaponComponentFromPed(ped, wHash, cHash)
                    end
                end

                for _, c in ipairs(baseComponents) do
                    local cHash = _hash(c)
                    if cHash ~= 0 then
                        if not HasPedGotWeaponComponent(ped, wHash, cHash) then
                            GiveWeaponComponentToPed(ped, wHash, cHash)
                        end
                    end
                end

                for _, c in ipairs(extraComponents) do
                    local cHash = _hash(c)
                    if cHash ~= 0 then
                        if not HasPedGotWeaponComponent(ped, wHash, cHash) then
                            GiveWeaponComponentToPed(ped, wHash, cHash)
                        end
                    end
                end
            end
        end
    end
end

local function applyExactSetLocal(ped, weaponName, desiredList)
    if type(desiredList) ~= 'table' then
        desiredList = {}
    end
    local wHash = _hash(weaponName)
    if wHash == 0 then return end

    SetCurrentPedWeapon(ped, wHash, true)

    local desired = {}
    for _, c in ipairs(desiredList) do
        desired[c] = true
    end

    for _, c in ipairs(knownComponentsForWeapon(weaponName)) do
        local cHash = _hash(c)
        if cHash ~= 0 and HasPedGotWeaponComponent(ped, wHash, cHash) and not desired[c] then
            RemoveWeaponComponentFromPed(ped, wHash, cHash)
        end
    end

    for _, c in ipairs(desiredList) do
        local cHash = _hash(c)
        if cHash ~= 0 and not HasPedGotWeaponComponent(ped, wHash, cHash) then
            GiveWeaponComponentToPed(ped, wHash, cHash)
        end
    end
end

function EKS_Loadouts_OpenLoadoutUI(context)
    if uiOpen then return end
    uiOpen = true
    SetNuiFocus(true, true)
    TriggerServerEvent('eks_loadouts:open_request', context or {})
end

local function openLoadoutUI()
    EKS_Loadouts_OpenLoadoutUI({})
end

local function closeLoadoutUI()
    if not uiOpen then return end
    uiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterNetEvent('eks_loadouts:open_ui', function(payload)
    if not uiOpen then
        uiOpen = true
        SetNuiFocus(true, true)
    end
    SendNUIMessage(payload)
end)

RegisterCommand('loadout', function()
    openLoadoutUI()
end, false)

RegisterCommand('eks_loadouts_open', function()
    openLoadoutUI()
end, false)

CreateThread(function()
    RegisterKeyMapping('eks_loadouts_open', 'Open Loadout Menu', 'keyboard', Config.OpenKey or 'F5')
end)

RegisterNUICallback('equip', function(data, cb)
    if data and data.id then
        TriggerServerEvent('eks_loadouts:equip',
            tostring(data.id),
            data.extras or {},
            data.armouryId,
            data.armouryLabel
        )
    end
    cb({ ok = true })
end)

RegisterNUICallback('addAttachments', function(data, cb)
    if data and data.selections then
        TriggerServerEvent('eks_loadouts:add_attachments', data.selections)
    end
    cb({ ok = true })
end)

RegisterNUICallback('close', function(_, cb)
    closeLoadoutUI()
    cb({ ok = true })
end)

RegisterNUICallback('escape', function(_, cb)
    closeLoadoutUI()
    cb({ ok = true })
end)

RegisterNetEvent('eks_loadouts:cl_equip', function(loadoutId, lo, extras)
    local ped = PlayerPedId()
    if lo then
        applyLoadoutLocal(ped, lo, extras)
    end
end)

RegisterNetEvent('eks_loadouts:cl_apply_exact', function(selections)
    local ped = PlayerPedId()
    if type(selections) ~= 'table' then return end
    for weaponName, comps in pairs(selections) do
        applyExactSetLocal(ped, weaponName, comps)
    end
end)

RegisterNetEvent('eks_loadouts:notify', function(msg)
    if Config.ChatNotify then
        TriggerEvent('chat:addMessage', {
            color = { 0, 150, 255 },
            multiline = true,
            args = { 'Loadouts', msg }
        })
    end
end)

RegisterNetEvent('eks_loadouts:client_equip', function(hash)
    local ped = PlayerPedId()
    if hash then
        SetCurrentPedWeapon(ped, hash, true)
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res == RES then
        SetNuiFocus(false, false)
    end
end)


local armouryPeds = {}
local oxTarget = nil

local function spawnArmouryPed(loc)
    if not loc or not loc.coords then return end

    local pedCfg = loc.ped or {}
    local modelName

    if pedCfg.type == 'mp' then
        if pedCfg.appearance and pedCfg.appearance.model then
            modelName = pedCfg.appearance.model
        else
            modelName = pedCfg.model or 'mp_m_freemode_01'
        end
    else
        modelName = pedCfg.model or 's_m_y_cop_01'
    end

    local model = _hash(modelName)
    if not IsModelInCdimage(model) or not IsModelValid(model) then
        print(('[EKS_Loadouts] Invalid ped model for armoury "%s": %s')
            :format(tostring(loc.id), tostring(modelName)))
        return
    end

    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end

    local x, y, z = loc.coords.x, loc.coords.y, loc.coords.z

local ped = CreatePed(4, model, x, y, z, loc.heading or 0.0, false, false)

SetEntityAsMissionEntity(ped, true, false)
SetEntityInvincible(ped, true)
SetBlockingOfNonTemporaryEvents(ped, true)
SetPedCanRagdoll(ped, false)

Wait(150)

SetEntityCoordsNoOffset(ped, x, y, z, false, false, false)

FreezeEntityPosition(ped, true)

    if pedCfg.type == 'mp' and pedCfg.appearance then
        local app = pedCfg.appearance

        if app.headBlend then
            SetPedHeadBlendData(
                ped,
                app.headBlend.shapeFirst or 0,
                app.headBlend.shapeSecond or 0,
                app.headBlend.shapeThird or 0,
                app.headBlend.skinFirst or 0,
                app.headBlend.skinSecond or 0,
                app.headBlend.skinThird or 0,
                app.headBlend.shapeMix or 0.0,
                app.headBlend.skinMix or 0.0,
                app.headBlend.thirdMix or 0.0,
                false
            )
        end

        if app.faceFeatures then
            for id, val in pairs(app.faceFeatures) do
                SetPedFaceFeature(ped, tonumber(id), val + 0.0)
            end
        end

        if app.hair then
            SetPedComponentVariation(ped, 2, app.hair.style or 0, 0, 2)
            SetPedHairColor(ped, app.hair.color or 0, app.hair.highlight or 0)
        end

        if app.eyeColor ~= nil then
            SetPedEyeColor(ped, tonumber(app.eyeColor))
        end

        if app.overlays then
            for overlayID, data in pairs(app.overlays) do
                SetPedHeadOverlay(
                    ped,
                    tonumber(overlayID),
                    data.index or 0,
                    data.opacity or 1.0
                )
            end
        end

        if app.components then
            for compId, data in pairs(app.components) do
                SetPedComponentVariation(
                    ped,
                    tonumber(compId),
                    data.drawable or 0,
                    data.texture or 0,
                    2
                )
            end
        end

        if app.props then
            for propId, data in pairs(app.props) do
                ClearPedProp(ped, tonumber(propId))
                if data.drawable and data.drawable >= 0 then
                    SetPedPropIndex(
                        ped,
                        tonumber(propId),
                        data.drawable,
                        data.texture or 0,
                        true
                    )
                end
            end
        end
    end

    if loc.blip then
        local blip = AddBlipForCoord(x, y, z)
        SetBlipSprite(blip, loc.blip.sprite or 110)
        SetBlipColour(blip, loc.blip.colour or 29)
        SetBlipScale(blip, loc.blip.scale or 0.8)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString(loc.label or 'Armoury')
        EndTextCommandSetBlipName(blip)
    end

    local label = loc.label or 'Armoury'
    if oxTarget then
        oxTarget:addLocalEntity(ped, {
            {
                name  = ('eks_loadouts_%s'):format(loc.id or 'armoury'),
                icon  = 'fa-solid fa-gun',
                label = label,
                onSelect = function()
                    TriggerServerEvent('eks_loadouts:open_request', {
                        armouryId    = loc.id,
                        armouryLabel = label
                    })
                end
            }
        })
    else
        CreateThread(function()
            local prompt = ('Press ~INPUT_CONTEXT~ to open %s'):format(label)
            while DoesEntityExist(ped) do
                local sleep = 1000
                local p = PlayerPedId()
                local pCoords = GetEntityCoords(p)
                local dist = #(pCoords - vec3(x, y, z))

                if dist < 2.0 then
                    sleep = 0
                    SetTextComponentFormat("STRING")
                    AddTextComponentString(prompt)
                    DisplayHelpTextFromStringLabel(0, false, true, -1)

                    if IsControlJustPressed(0, 38) then
                        TriggerServerEvent('eks_loadouts:open_request', {
                            armouryId    = loc.id,
                            armouryLabel = label
                        })
                    end
                end

                Wait(sleep)
            end
        end)
    end
    
    table.insert(armouryPeds, ped)
end

CreateThread(function()
    if not Config.Armoury or not Config.Armoury.Enabled then return end

    if Config.Armoury.UseOxTarget then
        if GetResourceState("ox_target") == "started" then
            oxTarget = exports.ox_target
        end
    end

    for _, loc in ipairs(Config.Armoury.Locations or {}) do
        spawnArmouryPed(loc)
    end
end)
