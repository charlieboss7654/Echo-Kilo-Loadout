local RES = GetCurrentResourceName()
local uiOpen = false

local function _hash(s)
    if type(joaat) == 'function' then return joaat(s) end
    return GetHashKey(s)
end

local function knownComponentsForWeapon(weaponName)
    local known = {}

    if Config.AttachmentCatalog and Config.AttachmentCatalog[weaponName] then
        for _, c in ipairs(Config.AttachmentCatalog[weaponName]) do known[c] = true end
    end
    if Config.Loadouts then
        for _, lo in pairs(Config.Loadouts) do
            if lo.weapons then
                for _, w in ipairs(lo.weapons) do
                    if w.name == weaponName and w.components then
                        for _, c in ipairs(w.components) do known[c] = true end
                    end
                end
            end
        end
    end

    local out = {}
    for c,_ in pairs(known) do out[#out+1] = c end
    return out
end

local function giveWeaponLocal(ped, weaponName, ammo, components, tint)
    local wHash = _hash(weaponName)
    if not wHash or wHash == 0 then return end
    GiveWeaponToPed(ped, wHash, ammo or 0, false, false)
    if tint ~= nil then SetPedWeaponTintIndex(ped, wHash, tint) end
    if components and type(components) == 'table' then
        for _, comp in ipairs(components) do
            local cHash = _hash(comp)
            if cHash ~= 0 then GiveWeaponComponentToPed(ped, wHash, cHash) end
        end
    end
end

local function applyExactSetLocal(ped, weaponName, desiredList)
    if type(desiredList) ~= 'table' then desiredList = {} end
    local wHash = _hash(weaponName); if wHash == 0 then return end

    SetCurrentPedWeapon(ped, wHash, true)

    local desired = {}
    for _, c in ipairs(desiredList) do desired[c] = true end

    for _, c in ipairs(knownComponentsForWeapon(weaponName)) do
        local cHash = _hash(c)
        if cHash ~= 0 and HasPedGotWeaponComponent(ped, wHash, cHash) and not desired[c] then
            RemoveWeaponComponentFromPed(ped, wHash, cHash)
        end
    end

    for _, c in ipairs(desiredList) do
        local cHash = _hash(c)
        if cHash ~= 0 then GiveWeaponComponentToPed(ped, wHash, cHash) end
    end

    SetCurrentPedWeapon(ped, wHash, true)
    SetAmmoInClip(ped, wHash, 1)
end

local function openLoadoutUI()
    if uiOpen then return end
    uiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        tree = Config.Tree or {},
        loadouts = Config.Loadouts or {},
        componentLabels = Config.ComponentLabels or {},
        attachmentCatalog = Config.AttachmentCatalog or {}
    })
end

local function closeLoadoutUI()
    if not uiOpen then return end
    uiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterCommand('loadout', function() openLoadoutUI() end, false)
RegisterCommand('eks_loadouts_open', function() openLoadoutUI() end, false)

CreateThread(function()
    RegisterKeyMapping('eks_loadouts_open', 'Open Loadout Menu', 'keyboard', Config.OpenKey or 'F5')
end)

RegisterNUICallback('equip', function(data, cb)
    if data and data.id then
        TriggerServerEvent('eks_loadouts:equip', tostring(data.id), data.extras or {})
    end
    cb({ ok = true })
end)

RegisterNUICallback('addAttachments', function(data, cb)
    if data and data.selections then
        TriggerServerEvent('eks_loadouts:add_attachments', data.selections)
    end
    cb({ ok = true })
end)

RegisterNUICallback('close', function(_, cb) closeLoadoutUI(); cb({}) end)
RegisterNUICallback('escape', function(_, cb) closeLoadoutUI(); cb({}) end)

RegisterNetEvent('eks_loadouts:cl_equip', function(loadoutId, loadoutData, extras)
    local ped = PlayerPedId()

    if Config.ClearBeforeGive then
        RemoveAllPedWeapons(ped, true)
    end

    local lastHash = nil
    if loadoutData.weapons then
        for _, w in ipairs(loadoutData.weapons) do
            giveWeaponLocal(ped, w.name, w.ammo or 0, w.components, w.tint)
            lastHash = _hash(w.name)
        end
    end

    if type(extras) == 'table' then
        for weaponName, list in pairs(extras) do
            applyExactSetLocal(ped, weaponName, list)
        end
    end

    if loadoutData.armour and loadoutData.armour > 0 then
        SetPedArmour(ped, loadoutData.armour)
    elseif Config.DefaultArmour and Config.DefaultArmour > 0 then
        SetPedArmour(ped, Config.DefaultArmour)
    end

    if lastHash then SetCurrentPedWeapon(ped, lastHash, true) end
    if Config.ChatNotify then
        TriggerEvent('chat:addMessage', { color = {0,200,255}, args = { 'Loadouts', ('Equipped: %s'):format(loadoutData.title or loadoutId) } })
    end
end)

RegisterNetEvent('eks_loadouts:cl_apply_exact', function(selections)
    local ped = PlayerPedId()
    for weaponName, list in pairs(selections or {}) do
        applyExactSetLocal(ped, weaponName, list)
    end
    if Config.ChatNotify then
        TriggerEvent('chat:addMessage', { color = {0,200,255}, args = { 'Loadouts', 'Attachments updated.' } })
    end
end)

RegisterNetEvent('eks_loadouts:notify', function(msg)
    if not msg or msg == '' then return end
    if Config.ChatNotify then
        TriggerEvent('chat:addMessage', {
            color = { 0, 200, 255 },
            multiline = true,
            args = { 'Loadouts', msg }
        })
    end
end)

RegisterNetEvent('eks_loadouts:client_equip', function(hash)
    local ped = PlayerPedId()
    if hash then SetCurrentPedWeapon(ped, hash, true) end
end)

AddEventHandler('onResourceStop', function(res)
    if res == RES then SetNuiFocus(false, false) end
end)
