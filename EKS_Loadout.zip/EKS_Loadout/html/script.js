const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'eks_loadouts';

const app = document.getElementById('app');
const navList = document.getElementById('navList');
const details = document.getElementById('loadoutDetails');
const btnEquip = document.getElementById('btnEquip');
const btnClose = document.getElementById('btnClose');
const btnCancel = document.getElementById('btnCancel');
const btnAttachments = document.getElementById('btnAttachments');
const breadcrumbEl = document.getElementById('breadcrumb');

const modal = document.getElementById('attachModal');
const attachList = document.getElementById('attachList');
const attachCancel = document.getElementById('attachCancel');
const attachApply = document.getElementById('attachApply');

let state = {
  tree: [],
  loadouts: {},
  componentLabels: {},
  attachmentCatalog: {},
  path: [],
  selectedLoadoutId: null,

  // NEW FOR VERSION 2
  permissions: {},        // { loadoutId: true/false }
  visibleLoadouts: null,  // { loadoutId: true }
  armoury: null,          // { id, label }
};

const pendingExtras = {};

function show(){ app.style.display = 'grid'; }
function hide(){ app.style.display = 'none'; }
function showModal(){ modal.style.display = 'flex'; }
function hideModal(){ modal.style.display = 'none'; }

function prettyLabelFromHash(hash){
  const lbl = state.componentLabels[hash];
  if (lbl) return lbl;
  return hash.replace(/^COMPONENT_/, '').replace(/_/g,' ').toLowerCase()
             .replace(/\b\w/g, c => c.toUpperCase());
}


function canUseLoadout(id) {
  if (!id) return false;
  if (state.permissions && state.permissions[id] !== undefined) {
    return !!state.permissions[id];
  }
  return true;
}

function isLoadoutVisible(id) {
  if (!state.visibleLoadouts) return true;
  return !!state.visibleLoadouts[id];
}


function setSelectedLoadout(id){
  state.selectedLoadoutId = id;

  const allowed = !!id && canUseLoadout(id) && isLoadoutVisible(id);
  btnEquip.disabled = !allowed;
  btnAttachments.disabled = !allowed;

  renderDetails();
  renderNav();
}

const getChildren   = (n)=> (n && n.children) ? n.children : [];
const getLoadoutIds = (n)=> (n && n.loadouts) ? n.loadouts : [];
const getCurrentNode= ()=> state.path.length ? state.path[state.path.length-1] : null;
const getRootNodes  = ()=> state.tree || [];

function renderBreadcrumb(){
  const parts = [];
  const rootCrumb = document.createElement('span');
  rootCrumb.className = 'crumb';
  rootCrumb.textContent = 'All Categories';
  rootCrumb.addEventListener('click', ()=>{
    state.path = [];
    state.selectedLoadoutId = null;
    btnEquip.disabled = true;
    btnAttachments.disabled = true;
    renderAll();
  });
  parts.push(rootCrumb);

  state.path.forEach((node, i)=>{
    const sep = document.createElement('span');
    sep.className = 'sep';
    sep.textContent = '>';
    parts.push(sep);

    const span = document.createElement('span');
    span.className = 'crumb';
    span.textContent = node.label || node.id;
    span.addEventListener('click', ()=>{
      state.path = state.path.slice(0, i+1);
      state.selectedLoadoutId = null;
      btnEquip.disabled = true;
      btnAttachments.disabled = true;
      renderAll();
    });
    parts.push(span);
  });

  breadcrumbEl.innerHTML = '';
  parts.forEach(el => breadcrumbEl.appendChild(el));
}

function renderNav(){
  navList.innerHTML = '';
  const container = document.createDocumentFragment();
  const node = getCurrentNode();
  const children = node ? getChildren(node) : getRootNodes();
  const loadoutIds = node ? getLoadoutIds(node) : [];
  const hasChildren = children.length > 0;
  const hasLoadouts = loadoutIds.length > 0;

  if (!hasChildren && !hasLoadouts){
    const empty = document.createElement('div');
    empty.className = 'placeholder';
    empty.style.padding = '8px';
    empty.textContent = 'No categories or loadouts here.';
    navList.appendChild(empty);
    return;
  }

  if (hasChildren){
    const section = document.createElement('div');
    section.className = 'section';
    section.innerHTML = '<h3>Categories</h3>';

    children.forEach(child=>{
      const item = document.createElement('div');
      item.className = 'item';
      item.innerHTML = `<div>${child.label || child.id}</div><span class="badge">Open</span>`;
      item.addEventListener('click', ()=>{
        state.path.push(child);
        state.selectedLoadoutId = null;
        btnEquip.disabled = true;
        btnAttachments.disabled = true;
        renderAll();
      });
      section.appendChild(item);
    });

    container.appendChild(section);
  }

  if (hasLoadouts){
    const section = document.createElement('div');
    section.className = 'section';
    section.innerHTML = '<h3>Loadouts</h3>';

    loadoutIds.forEach(id=>{
      if (!isLoadoutVisible(id)) return;

      const lo = state.loadouts[id];
      const allowed = canUseLoadout(id);

      let classes = 'item';
      if (id === state.selectedLoadoutId) classes += ' active';
      if (!allowed) classes += ' disabled';

      const item = document.createElement('div');
      item.className = classes;
      item.innerHTML = `<div>${(lo && lo.title) ? lo.title : id}</div>`;

      if (allowed){
        item.addEventListener('click', ()=> setSelectedLoadout(id));
      }

      section.appendChild(item);
    });

    container.appendChild(section);
  }

  navList.appendChild(container);
}

function renderDetails(){
  const id = state.selectedLoadoutId;
  if (!id){
    details.innerHTML = '<div class="placeholder">Pick a category, then choose a loadout.</div>';
    return;
  }

  const lo = state.loadouts[id];
  if (!lo){
    details.innerHTML = '<div class="placeholder">Loadout not found.</div>';
    return;
  }

  const armour = lo.armour ?? 0;
  const weapons = lo.weapons || [];

  const parts = [];
  parts.push(`
    <div class="loadout-head">
      <div class="loadout-title">${lo.title || id}</div>
      ${lo.description ? `<div class="loadout-desc">${lo.description}</div>` : ''}
    </div>
  `);

  parts.push(`
    <div class="statrow">
      <div class="stat">Armour: ${armour}</div>
      <div class="stat">Weapons: ${weapons.length}</div>
    </div>
  `);

  if (!weapons.length){
    parts.push('<div class="placeholder">No weapons configured for this loadout.</div>');
  } else {
    weapons.forEach(w=>{
      const comps = (w.components || [])
        .map(c => `<span class="chip">${prettyLabelFromHash(c)}</span>`)
        .join('');

      parts.push(`
        <div class="weapon">
          <div class="weapon-title">
            <div class="weapon-name">${w.label || w.name}</div>
            <span class="badge">Ammo: ${w.ammo ?? 0}</span>
          </div>
          <div class="attachments">${comps || '<span class="chip">No attachments</span>'}</div>
        </div>
      `);
    });
  }

  details.innerHTML = parts.join('');
}

function renderAll(){
  renderBreadcrumb();
  renderNav();
  renderDetails();
}


function open(data){
  state.tree = data.tree || [];
  state.loadouts = data.loadouts || [];
  state.componentLabels = data.componentLabels || {};
  state.attachmentCatalog = data.attachmentCatalog || {};

  // NEW
  state.permissions = data.permissions || {};
  state.visibleLoadouts = data.visibleLoadouts || null;
  state.armoury = data.armoury || null;

  state.path = [];
  state.selectedLoadoutId = null;
  btnEquip.disabled = true;
  btnAttachments.disabled = true;

  renderAll();
  show();
}

window.addEventListener('message', (e)=>{
  const data = e.data || {};
  if (data.action === 'open') open(data);
  else if (data.action === 'close') hide();
});


btnEquip.addEventListener('click', ()=>{
  if (!state.selectedLoadoutId) return;
  if (!canUseLoadout(state.selectedLoadoutId)) return;

  let extras = pendingExtras[state.selectedLoadoutId] || {};

  if (modal.style.display === 'flex') {
    extras = collectSelectionsFromModal();
    pendingExtras[state.selectedLoadoutId] = extras;
  }

  const payload = {
    id: state.selectedLoadoutId,
    extras: extras
  };

  if (state.armoury) {
    payload.armouryId = state.armoury.id;
    payload.armouryLabel = state.armoury.label;
  }

  fetch(`https://${RES}/equip`, {
    method:'POST',
    headers:{'Content-Type':'application/json; charset=UTF-8'},
    body: JSON.stringify(payload)
  }).finally(()=>{
    fetch(`https://${RES}/close`, { method:'POST' });
    hide();
  });
});

function collectSelectionsFromModal() {
  const selections = {};
  Array.from(attachList.querySelectorAll('.attach-row')).forEach(row=>{
    const weapon = row.dataset.weapon;
    const comps = Array.from(row.querySelectorAll('input[type="checkbox"]:checked')).map(i => i.value);
    selections[weapon] = comps || [];
  });
  return selections;
}

btnAttachments.addEventListener('click', ()=>{
  if (!state.selectedLoadoutId) return;
  if (!canUseLoadout(state.selectedLoadoutId)) return;

  const lo = state.loadouts[state.selectedLoadoutId];
  const weapons = (lo && lo.weapons) ? lo.weapons : [];
  attachList.innerHTML = '';

  weapons.forEach(w=>{
    const avail = state.attachmentCatalog[w.name] || [];
    if (!avail.length) return;

    const row = document.createElement('div');
    row.className = 'attach-row';
    row.dataset.weapon = w.name;

    const title = document.createElement('div');
    title.className = 'attach-title';
    title.textContent = w.label || w.name;
    row.appendChild(title);

    const grid = document.createElement('div');
    grid.className = 'attach-grid';

    const current = new Set((w.components || []));
    const pending = (pendingExtras[state.selectedLoadoutId] && pendingExtras[state.selectedLoadoutId][w.name]) || [];
    pending.forEach(c => current.add(c));

    avail.forEach(comp=>{
      const lbl = prettyLabelFromHash(comp);
      const wrap = document.createElement('label');
      wrap.className = 'check';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = comp;
      cb.checked = current.has(comp);
      wrap.appendChild(cb);
      const span = document.createElement('span');
      span.textContent = lbl;
      wrap.appendChild(span);
      grid.appendChild(wrap);
    });

    row.appendChild(grid);
    attachList.appendChild(row);
  });

  showModal();
});


btnClose.addEventListener('click', ()=>{
  fetch(`https://${RES}/close`, { method:'POST' });
  hide();
});

btnCancel.addEventListener('click', ()=>{
  fetch(`https://${RES}/close`, { method:'POST' });
  hide();
});

window.addEventListener('keydown', (e)=>{
  if (e.key === 'Escape'){
    fetch(`https://${RES}/escape`, { method:'POST' });
    hide();
  }
});
