local function hasRequiredDiscordRole(src, roleIds)
    if type(roleIds) ~= 'table' or #roleIds == 0 then
        return true
    end

    local ok, roles = pcall(function()
        return exports.Badger_Discord_API:GetDiscordRoles(src)
    end)

    if not ok or not roles then
        return false
    end

    local roleSet = {}
    for _, v in pairs(roles) do
        roleSet[tostring(v)] = true
    end

    for _, required in ipairs(roleIds) do
        if roleSet[tostring(required)] then
            return true
        end
    end

    return false
end

RegisterNetEvent('eks_loadouts:open_request', function(context)
    local src = source
    if type(context) ~= 'table' then context = {} end

    local loadouts = Config.Loadouts or {}
    local tree     = Config.Tree or {}

    local permissions = {}
    for id, lo in pairs(loadouts) do
        local allowed = true
        if lo.discordRoles then
            allowed = hasRequiredDiscordRole(src, lo.discordRoles)
        end
        permissions[id] = allowed
    end

    local visibleLoadouts = {}
    local armouryLabel

    if Config.Armoury and Config.Armoury.Enabled and context.armouryId and Config.Armoury.Locations then
        for _, loc in ipairs(Config.Armoury.Locations) do
            if loc.id == context.armouryId then
                armouryLabel = loc.label or loc.id
                if type(loc.loadouts) == 'table' then
                    for _, lid in ipairs(loc.loadouts) do
                        visibleLoadouts[lid] = true
                    end
                end
                break
            end
        end
    end

    if next(visibleLoadouts) == nil then
        for id, _ in pairs(loadouts) do
            visibleLoadouts[id] = true
        end
    end

    local payload = {
        action            = 'open',
        tree              = tree,
        loadouts          = loadouts,
        componentLabels   = Config.ComponentLabels or {},
        attachmentCatalog = Config.AttachmentCatalog or {},
        permissions       = permissions,
        visibleLoadouts   = visibleLoadouts,
        armoury           = (context.armouryId and {
            id    = context.armouryId,
            label = context.armouryLabel or armouryLabel or context.armouryId
        } or nil)
    }

    TriggerClientEvent('eks_loadouts:open_ui', src, payload)
end)

RegisterNetEvent('eks_loadouts:equip', function(loadoutId, extras, armouryId, armouryLabel)
    local src = source
    if type(loadoutId) ~= 'string' then return end

    local lo = Config.Loadouts and Config.Loadouts[loadoutId]
    if not lo then
        TriggerClientEvent('eks_loadouts:notify', src, 'Invalid loadout requested.')
        return
    end

    if lo.discordRoles and not hasRequiredDiscordRole(src, lo.discordRoles) then
        TriggerClientEvent('eks_loadouts:notify', src, 'You are not authorised to use that loadout.')
        return
    end

    if Config.ArmouryWebhook and Config.ArmouryWebhook ~= '' then
        local armouryName = armouryLabel or armouryId or 'Global Loadout Menu'
        local playerName  = GetPlayerName(src) or ('ID ' .. tostring(src))

        local weaponLines = {}
        if lo.weapons then
            for _, w in ipairs(lo.weapons) do
                local label = w.label or w.name or 'Unknown'
                table.insert(weaponLines, string.format('- %s (%s)', label, w.name or ''))
            end
        end
        local weaponText = (#weaponLines > 0) and table.concat(weaponLines, '\n') or 'None'

        local descLines = {
            string.format('**Player:** %s', playerName),
            string.format('**Server ID:** %d', src),
            string.format('**Armoury:** %s', armouryName),
            string.format('**Time:** %s', os.date('%Y-%m-%d %H:%M:%S')),
            '',
            string.format('**Loadout:** %s (%s)', lo.title or loadoutId, loadoutId),
            '',
            '**Weapons:**',
            weaponText
        }

        local embed = {
            title       = 'Armoury Loadout Taken',
            description = table.concat(descLines, '\n'),
            color       = 5814783
        }

        local body = {
            username = 'EKS Loadouts',
            embeds   = { embed }
        }

        PerformHttpRequest(
            Config.ArmouryWebhook,
            function() end,
            'POST',
            json.encode(body),
            { ['Content-Type'] = 'application/json' }
        )
    end

    TriggerClientEvent('eks_loadouts:cl_equip', src, loadoutId, lo, extras or {})
end)

RegisterNetEvent('eks_loadouts:add_attachments', function(selections)
    local src = source
    if type(selections) ~= 'table' then return end
    TriggerClientEvent('eks_loadouts:cl_apply_exact', src, selections)
end)
