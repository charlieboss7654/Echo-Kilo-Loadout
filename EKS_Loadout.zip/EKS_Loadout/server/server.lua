RegisterNetEvent('eks_loadouts:equip', function(loadoutId, extras)
    local src = source
    if type(loadoutId) ~= 'string' then return end

    local lo = Config.Loadouts and Config.Loadouts[loadoutId]
    if not lo then
        TriggerClientEvent('eks_loadouts:notify', src, 'Invalid loadout requested.')
        return
    end

    TriggerClientEvent('eks_loadouts:cl_equip', src, loadoutId, lo, extras or {})
end)

RegisterNetEvent('eks_loadouts:add_attachments', function(selections)
    local src = source
    if type(selections) ~= 'table' then return end

    TriggerClientEvent('eks_loadouts:cl_apply_exact', src, selections)
end)
