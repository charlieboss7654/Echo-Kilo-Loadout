fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'eks_loadouts'
author 'Cowboy - Echo Kilo Stduios'
version '1.1.0'
description 'Simple Loadout Menu with a nice sleek UI!'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/styles.css',
  'html/script.js'
}

shared_scripts {
  'shared/config.lua'
}

client_scripts {
  'client/client.lua'
}

server_scripts {
  'server/server.lua'
}
